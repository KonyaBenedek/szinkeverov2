﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace wépéjef_applikáció
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void SzinKeveres()
        {
            rctSzin.Fill = new SolidColorBrush(Color.FromRgb(Convert.ToByte(sliPiros.Value), Convert.ToByte(sliZold.Value), Convert.ToByte(sliKek.Value)));
                
        }

        private void sliPiros_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            SzinKeveres();
            labPiros.Content = Math.Floor(sliPiros.Value);
        }

        private void sliZold_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            SzinKeveres();
            labZold.Content = Math.Floor(sliZold.Value);
        }

        private void sliKek_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            SzinKeveres();
            labKek.Content = Math.Floor(sliKek.Value);
        }

        private void btnRogzit_Click(object sender, RoutedEventArgs e)
        {
           double piros = Math.Floor(Convert.ToDouble(sliPiros.Value));
           double zold = Math.Floor(Convert.ToDouble(sliZold.Value));
           double kek = Math.Floor(Convert.ToDouble(sliKek.Value));

            string szinAdatok = $"{piros};{zold};{kek}";

            if (lbSzinek.Items.Contains(szinAdatok))
            {
                MessageBox.Show("A lista már tartalmazza ezt az értéket (っ °Д °;)っ ", "Színkeverő 0.2");
            }else
            {
                lbSzinek.Items.Add(szinAdatok);
                MessageBox.Show("Sikeres hozzádás (∩^o^)⊃━☆", "Színkeverő 0.2");
            }
        }

        private void btnTorol_Click(object sender, RoutedEventArgs e)
        {
            if (lbSzinek.SelectedIndex  < 0 && lbSzinek.Items.Count == 0)
            {
                MessageBox.Show("A lista már üres öcsi (∩^o^)⊃━☆", "Színkeverő 0.2");
            }
            else if (lbSzinek.SelectedIndex < 0)
            {
                MessageBox.Show("Nincs egy elem sincs kiválasztva (っ °Д °;)っ", "Színkeverő 0.2");
            }
            else
            {
                
                lbSzinek.Items.RemoveAt(lbSzinek.SelectedIndex);
                MessageBox.Show("Sikeres törlés \\^o^/", "Színkeverő 0.2");
            }
        }

        private void btnUrit_Click(object sender, RoutedEventArgs e)
        {
            lbSzinek.Items.Clear();
            if (lbSzinek.Items.Count == 0 )
            {
                MessageBox.Show("A lista már üres öcsi (∩^o^)⊃━☆", "Színkeverő 0.2");
            }
        }

       /* private void lbSzinek_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
          string[] RGBCol = lbSzinek.Items[lbSzinek.SelectedIndex].ToString().Split(';');
            
            sliPiros.Value = Convert.ToByte(RGBCol[0]);
            sliZold.Value = Convert.ToByte(RGBCol[1]);
            sliKek.Value = Convert.ToByte(RGBCol[2]);
        }*/

        private void lbSzinek_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            string[] RGBCol = lbSzinek.Items[lbSzinek.SelectedIndex].ToString().Split(';');

            sliPiros.Value = Convert.ToByte(RGBCol[0]);
            sliZold.Value = Convert.ToByte(RGBCol[1]);
            sliKek.Value = Convert.ToByte(RGBCol[2]);
        }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            if (MessageBox.Show("Biztosan ki akarsz lénpi a programból?", "Színkeverő 0.2", MessageBoxButton.YesNo,
                MessageBoxImage.Question) == MessageBoxResult.No)
            {
                e.Cancel = true;
            }
        }
    }
}
